
alias Package.Admin

   user =%{ username: "admin",
   password: "admin",
   password_confirmation: "admin"
  }
  Admin.create_user(user)