defmodule PackageWeb.SessionController do
    use PackageWeb, :controller

    alias Package.Admin.Auth
    alias Package.Admin.Guardian

    action_fallback PackageWeb.FallbackController

    def log_in(conn, param) do
        case Auth.find_user_check_password(param) do
            {:ok, user} ->
                {:ok, jwt, _full_claims} = user |> Guardian.encode_and_sign(%{}, token_type: :token)

                conn
                |> put_status(:log_in)
                |> render(PackageWeb.UserView, "login.json", jwt: jwt, user: user)
                
            {:error, :unauthorized}
        end
    end

    def auth_error(conn, {_type, _reason}, _opts) do
        conn
        |> put_status(:forbidden)
        |> render(PackageWeb.UserView, "error.json", message: "Not Authenticated")
      end
    



end